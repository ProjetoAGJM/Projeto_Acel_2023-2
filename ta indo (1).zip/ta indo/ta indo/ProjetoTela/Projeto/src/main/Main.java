package main;

import view.Principal;
import conexoes.ConexaoSQLite;
import control.*;
import java.sql.PreparedStatement;
import java.util.Scanner;



public class Main {
    
   public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
        
        ConexaoSQLite conexaoSQLite = new ConexaoSQLite();
        CriarTabelas criarTabelas = new CriarTabelas(conexaoSQLite);
        PreparedStatement preparedStatement = null;
        conexaoSQLite.conectar();

       
    Principal pri = new Principal();
    pri.setVisible(true);
    
}
    
    
}
