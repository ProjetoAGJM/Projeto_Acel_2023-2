package control;

import java.sql.ResultSet;
import model.*;
import conexoes.ConexaoSQLite;
import java.sql.SQLException;
import java.util.Scanner;
import model.Usuario_GS;
import java.sql.PreparedStatement;

public class Usuario_C {

    ConexaoSQLite conexaoSQLite = new ConexaoSQLite();
    Usuario_GS usuario_gs = new Usuario_GS();

    public void adiciona_usuario(String user, String senha, String nome, String email, String telefone) {
        conexaoSQLite.conectar();

        usuario_gs.setUser(user);
        usuario_gs.setSenha(senha);
        usuario_gs.setNivel(3);
        usuario_gs.setTelefone(telefone);
        usuario_gs.setNome(nome);
        usuario_gs.setEmail(email);

        String sqlInsert = "INSERT INTO tbl_usuario ("
                + " user," + " senha," + " nivel," + " telefone," + "nome," + " email" + ") VALUES(?,?,?,?,?,?)"
                + ";";

        PreparedStatement preparedStatement = conexaoSQLite.criarPreparedStatment(sqlInsert);

        try {

            preparedStatement.setString(1, usuario_gs.getUser());
            preparedStatement.setString(2, usuario_gs.getSenha());
            preparedStatement.setInt(3, usuario_gs.getNivel());
            preparedStatement.setString(4, usuario_gs.getTelefone());
            preparedStatement.setString(5, usuario_gs.getNome());
            preparedStatement.setString(6, usuario_gs.getEmail());

            int resultado = preparedStatement.executeUpdate();

            if (resultado == 1) {
                System.out.println("pessoa inserida");
            } else {
                System.out.println("deu pau");
            }

        } catch (SQLException e) {
            // Print the stack trace for debugging purposes
            e.printStackTrace();
            // Alternatively, you can log the exception message
            // System.out.println("Error: " + e.getMessage());
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        }

    }

    public void adiciona_personal(String user, String senha, String nome, String email, String telefone) {
        conexaoSQLite.conectar();

        usuario_gs.setUser(user);
        usuario_gs.setSenha(senha);
        usuario_gs.setNivel(2);
        usuario_gs.setTelefone(telefone);
        usuario_gs.setNome(nome);
        usuario_gs.setEmail(email);

        String sqlInsert = "INSERT INTO tbl_usuario ("
                + " user," + " senha," + " nivel," + " telefone," + "nome," + " email" + ") VALUES(?,?,?,?,?,?)"
                + ";";

        PreparedStatement preparedStatement = conexaoSQLite.criarPreparedStatment(sqlInsert);

        try {

            preparedStatement.setString(1, usuario_gs.getUser());
            preparedStatement.setString(2, usuario_gs.getSenha());
            preparedStatement.setInt(3, usuario_gs.getNivel());
            preparedStatement.setString(4, usuario_gs.getTelefone());
            preparedStatement.setString(5, usuario_gs.getNome());
            preparedStatement.setString(6, usuario_gs.getEmail());

            int resultado = preparedStatement.executeUpdate();

            if (resultado == 1) {
                System.out.println("pessoa inserida");
            } else {
                System.out.println("deu pau");
            }

        } catch (SQLException e) {
            // Print the stack trace for debugging purposes
            e.printStackTrace();
            // Alternatively, you can log the exception message
            // System.out.println("Error: " + e.getMessage());
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        }

    }
    
    public void adiciona_gerente(String user, String senha, String nome, String email, String telefone) {
        conexaoSQLite.conectar();

        usuario_gs.setUser(user);
        usuario_gs.setSenha(senha);
        usuario_gs.setNivel(1);
        usuario_gs.setTelefone(telefone);
        usuario_gs.setNome(nome);
        usuario_gs.setEmail(email);

        String sqlInsert = "INSERT INTO tbl_usuario ("
                + " user," + " senha," + " nivel," + " telefone," + "nome," + " email" + ") VALUES(?,?,?,?,?,?)"
                + ";";

        PreparedStatement preparedStatement = conexaoSQLite.criarPreparedStatment(sqlInsert);

        try {

            preparedStatement.setString(1, usuario_gs.getUser());
            preparedStatement.setString(2, usuario_gs.getSenha());
            preparedStatement.setInt(3, usuario_gs.getNivel());
            preparedStatement.setString(4, usuario_gs.getTelefone());
            preparedStatement.setString(5, usuario_gs.getNome());
            preparedStatement.setString(6, usuario_gs.getEmail());

            int resultado = preparedStatement.executeUpdate();

            if (resultado == 1) {
                System.out.println("pessoa inserida");
            } else {
                System.out.println("deu pau");
            }

        } catch (SQLException e) {
            // Print the stack trace for debugging purposes
            e.printStackTrace();
            // Alternatively, you can log the exception message
            // System.out.println("Error: " + e.getMessage());
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        }

    }
    
    public boolean le_usuario(String user, String senha) {

        conexaoSQLite.conectar();

        boolean status = false;
        ResultSet resultSet = null;
        PreparedStatement preparedStatement = null;

        String sql = "SELECT * "
                + " FROM tbl_usuario"
                + " WHERE user = ? AND senha = ?";

        try {

            preparedStatement = conexaoSQLite.criarPreparedStatment(sql);

            preparedStatement.setString(1, user);
            preparedStatement.setString(2, senha);

            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                usuario_gs.setUser(resultSet.getString("user"));
                usuario_gs.setTelefone(resultSet.getString("telefone"));
                usuario_gs.setSenha(resultSet.getString("senha"));
                usuario_gs.setNome(resultSet.getString("nome"));
                usuario_gs.setNivel(resultSet.getInt("nivel"));
                usuario_gs.setId_usuario(resultSet.getInt("id_usuario"));
                usuario_gs.setEmail(resultSet.getString("email"));

                System.out.println("deu");
                status = true;

            }

        } catch (SQLException e) {

        }
        if (status == false) {

            System.out.println("nao deu");

        }

        return status;
    }

    public Usuario_GS dados(String user) {

        conexaoSQLite.conectar();

        boolean status = false;
        ResultSet resultSet = null;
        PreparedStatement preparedStatement = null;

        String sql = "SELECT * "
                + " FROM tbl_usuario"
                + " WHERE user = ?";

        try {

            preparedStatement = conexaoSQLite.criarPreparedStatment(sql);

            preparedStatement.setString(1, user);

            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                usuario_gs.setUser(resultSet.getString("user"));
                usuario_gs.setTelefone(resultSet.getString("telefone"));
                usuario_gs.setSenha(resultSet.getString("senha"));
                usuario_gs.setNome(resultSet.getString("nome"));
                usuario_gs.setNivel(resultSet.getInt("nivel"));
                usuario_gs.setId_usuario(resultSet.getInt("id_usuario"));
                usuario_gs.setEmail(resultSet.getString("email"));

                System.out.println("deu");
                status = true;

            }

        } catch (SQLException e) {

        }
        if (status == false) {

            System.out.println("nao deu");

        }

        return usuario_gs;
    }

    public int getIDUser() {

        return usuario_gs.getNivel();
    }
    
    public int getID() {

        return usuario_gs.getId_usuario();
    }

    public boolean vazio(String user, String senha, String nome, String email, String telefone) {
        boolean status = true;
        if (user.isEmpty() || senha.isEmpty() || nome.isEmpty() || email.isEmpty() || telefone.isEmpty()) {
            status = false;
        }
        return status;
    }

    public void altera_usuario(String user, String senha, String nome, String email, String telefone, int id) {

        ConexaoSQLite conexaoSQLite = new ConexaoSQLite();
        PreparedStatement preparedStatement = null;
        Scanner scanner = new Scanner(System.in);
        conexaoSQLite.conectar();

        try {
            
            String sql = "UPDATE tbl_usuario SET user = ?, senha = ?, nome = ?, email = ?, telefone = ? WHERE id_usuario = ?;";
            preparedStatement = conexaoSQLite.criarPreparedStatment(sql);

            preparedStatement.setString(1, user);
            preparedStatement.setString(2, senha);
            preparedStatement.setString(3, nome);
            preparedStatement.setString(4, email);
            preparedStatement.setString(5, telefone);
             preparedStatement.setInt(6, id);
            

            int linhasAfetadas = preparedStatement.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("Usuário atualizado com sucesso!");
            } else {
                System.out.println("Nenhum usuário encontrado para atualizar.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            scanner.close(); // Feche o scanner no bloco finally para garantir que ele seja fechado
        }
    }

    public void deleta_usuario(int id) {

        ConexaoSQLite conexaoSQLite = new ConexaoSQLite();
        PreparedStatement preparedStatement = null;
        conexaoSQLite.conectar();

        String sql = "DELETE FROM tbl_usuario"
                + " WHERE id_usuario = ?;";

        try {

            preparedStatement = conexaoSQLite.criarPreparedStatment(sql);
            preparedStatement.setInt(1, id);

            preparedStatement.executeUpdate();

            System.out.println("foras deletadas registros");

        } catch (SQLException e) {

            e.printStackTrace();

        }

    }

}
