

package control;

import conexoes.ConexaoSQLite;
import java.sql.SQLException;
import java.sql.Statement;

public class CriarTabelas {

    private final ConexaoSQLite conexaoSQLite;

    public CriarTabelas(ConexaoSQLite pconexaoSQLite) {
        this.conexaoSQLite = pconexaoSQLite;
    }

    public void criarTabelaUsuario() {



        String sql = "CREATE TABLE IF NOT EXISTS tbl_usuario ("
                + "id_usuario integer PRIMARY KEY AUTOINCREMENT,"
                + "user text NOT NULL,"
                + "senha text NOT NULL,"
                + "nome text NOT NULL,"
                + "email text NOT NULL,"
                + "telefone text NOT NULL,"
                + "nivel integer"
                + ")";

        // Executando o SQL para criar a tabela
        boolean conectou = false;

        try {

            Statement stmt = this.conexaoSQLite.criarStatment();
            stmt.execute(sql);
            System.out.println("Tabela usuario criada");
        } catch (SQLException ignored) {
        }

    }



}

