
package conexoes;

import java.sql.*;

public class ConexaoSQLite {
    private Connection conexao;


    //conecta ao banco e cria se ele nao existir
    public boolean conectar(){

        try{
            String url = "jdbc:sqlite:banco_de_dados/banco_sqlite.db";

            this.conexao = DriverManager.getConnection(url);
        }

        catch(SQLException e){

            System.err.println(e.getMessage());
            return false;
        }

        System.out.println("conecto");

        return true;
    }

    public boolean desconectar(){

        try{
            if(this.conexao.isClosed()==false){
                this.conexao.close();
            }
        }

        catch(SQLException e){

            System.err.println(e.getMessage());
            return false;

        }

        System.out.println("desconecto");
        return true;
    }
    //cria statament

    public Connection getConn(){
        return conexao;
    }

    public Statement criarStatment(){

        try{
            return this.conexao.createStatement();
        }

        catch(SQLException e){
            return null;
        }
    }



    public PreparedStatement criarPreparedStatment(String sql){

        try{
            return this.conexao.prepareStatement(sql);
        }

        catch(SQLException e){
            return null;
        }
    }

    public Connection getConexao(){
        return this.conexao;
    }

}
